# Meu Projeto de Inteligência Artificial

Este é um repositório de estudos para desenvolver uma inteligência artificial do zero em 8 semanas.

## Estrutura

- `semana01` a `semana08`: conteúdos e exercícios semanais
- `cronograma.txt`: plano de estudos com links e tarefas
- Notebooks: prontos para você praticar e evoluir

## Objetivo
Criar uma base sólida em Python, matemática e machine learning até criar um projeto de IA próprio.
